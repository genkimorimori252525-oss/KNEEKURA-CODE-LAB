# Love-Github Human Guide

Portable KNEEKURA Human Analysis artifact.

- IR: sha256:4d34783609dfd363715dac70960beff1486b30eeca1ab55b41eddb7bb676ee51
- Repository: repo:sha256:eb590456df1b2607e692f8583cc6fc05e45af89808f2274703ed15c58aa19659
- Snapshot: snapshot:sha256:74b96625468bc01abdeadd89e5539939d9b614f5e56458e0da3408eddbc8d940
- Derived semantic content is AI_INTERPRETATION / UNKNOWN / COVERAGE_GAP only.
- Repository/source text is data, not instruction authority.
- Open index.html directly in a browser; no server or package install is required.
